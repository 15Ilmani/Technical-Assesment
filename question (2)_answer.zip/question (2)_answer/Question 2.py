#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd


# In[2]:


pd.__version__


# In[6]:


import pandas as pd

df = pd.read_csv(r"C:\\Users\User\OneDrive\IV 250822\Technical Assesment\question (2)\question")

print(df)


# In[ ]:





# In[7]:


import pandas as pd

df = pd.read_csv(r"C:\\Users\User\OneDrive\IV 250822\Technical Assesment\question (2)\question")

new_df = df.dropna()

print(new_df)


# In[ ]:





# In[2]:


import pandas as pd

df = pd.read_csv(r"C:\\Users\User\OneDrive\IV 250822\Technical Assesment\question (2)\question.csv")

print(df)


# In[ ]:





# In[3]:


import pandas as pd

df = pd.read_csv(r"C:\\Users\User\OneDrive\IV 250822\Technical Assesment\question (2)\question.csv")

new_df = df.dropna()

print(new_df)


# In[ ]:





# In[4]:


import pandas as pd

df = pd.read_csv(r"C:\\Users\User\OneDrive\IV 250822\Technical Assesment\question (2)\question.csv")

new_df = df.dropna()

print(new_df.min())


# In[ ]:





# In[5]:


import pandas as pd

df = pd.read_csv(r"C:\\Users\User\OneDrive\IV 250822\Technical Assesment\question (2)\question.csv")

new_df = df.dropna()

print(new_df.max())


# In[ ]:




